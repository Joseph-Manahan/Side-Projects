/*
 * **********************************************
 * San Francisco State University
 * CSC 220 -  Data Structures
 * File Name: LinkedBag.java
 * Author: Frank M. Carrano
 * Author: Timothy M. Henry
 * Author: Duc Ta
 * Author: <First Name> <Last Name>
 * **********************************************
 */

package assignment03PartA;


public final class LinkedBag<T> implements PrimaryDataStructureBagInterface<T> {

    private Node firstNode;
    private int numberOfEntries;


    public LinkedBag() {
        firstNode = null;
        numberOfEntries = 0;
    }
    private class Node {
        private T data;
        private Node next;

        private Node(T dataPortion) {
            this(dataPortion, null);
        } // end constructor

        private Node(T dataPortion, Node nextNode) {
            data = dataPortion;
            next = nextNode;
        }
    }

    @Override
    public int getCurrentSize() {
        return numberOfEntries;
    }

    @Override
    public boolean isEmpty() {
        return numberOfEntries == 0;
    }

    @Override
    public boolean add(T newEntry) {
        Node newNode = new Node (newEntry, firstNode);
        newNode.next = firstNode;
        firstNode = newNode;
        numberOfEntries++;
        return true;
    }

    @Override
    public boolean removeAllOccurrences(T[][] entries) {
        {
            T[] arr1D = null;
            boolean duplicate;

            System.out.println("[+] Removing 2D test array items from the bag...");
            System.out.println(" [-] Converting 2D array to 1D...");

            for(int r=0; r<entries.length; r++) {
                for(int c=0;c<entries[r].length;c++) {

                    duplicate = false;

                    if(arr1D == null) {
                        arr1D = (T[]) new Object[1];
                        arr1D[0] = entries[r][c];
                    }
                    else {
                        for(int i=0;i<arr1D.length;i++) {
                            if(arr1D[i].equals(entries[r][c])){
                                duplicate = true;
                                break;
                            }
                        }

                    if(!duplicate){ // inserts non duplicates into the 1D array
                        T[] noDups = (T[])new Object[arr1D.length+1];

                        for(int j=0; j<arr1D.length; j++) {
                            noDups[j] = arr1D[j];
                        }

                            noDups[noDups.length-1] = entries[r][c];
                            arr1D = noDups;
                        }
                    }
                }
            }

            System.out.println(" [-] Removing duplicates in 1D array...");
            System.out.print(" [>] The final 1D array now contains: ");

            for(int i=0;i<arr1D.length;i++) //iterates through the 1D array to print non-duplicate strings
                System.out.print(arr1D[i] + " ");
                System.out.println();


            System.out.println(" [-] Removing the final 1D array items from the bag...");

            duplicate = false;
            LinkedBag<T> removed = new LinkedBag(); //linked bag for all the removed strings
            Node node = firstNode;

            while(node != null){
                duplicate = false;
                for(int i=0;i<arr1D.length;i++){
                    if(arr1D[i].equals(node.data)){
                        duplicate = true;
                        break;
                    }
                }
                if(!duplicate)
                    removed.add(node.data);
                node = node.next;
            }
            firstNode = removed.firstNode;
            numberOfEntries = removed.numberOfEntries;

            return duplicate;

        }
    }

    @Override
    public T[] toArray() {
        T[] result = (T[]) new Object[numberOfEntries];

        int index = 0;
        Node currentNode = firstNode;
        while ((index<numberOfEntries) && (currentNode != null)) {
            result[index] = currentNode.data;
            index++;
            currentNode=currentNode.next;
        }
        return result;
    }
}