/*
 * **********************************************
 * San Francisco State University
 * CSC 220 -  Data Structures
 * File Name: Assignment03PartE03.java
 * Author: Duc Ta
 * Author: <Joseph> <Manahan>
 * **********************************************
 */
import java.util.Scanner;

public class Assignment3E3 {

    static long startTime;
    static long endTime;

    public static void main(String args[]) {
        Scanner in = new Scanner (System.in);
        int n;
        System.out.print("Enter value for n (type '002' to break):");
        n = in.nextInt();
        do {
            loopA(n); loopC(n);
            System.out.print("\nEnter value for n (type '002' to break):");
            n = in.nextInt();
        } while (n != 002);
        System.out.println("End");
    }

    public static void loopA (int n) {
        // Loop A
        startTime = System.nanoTime();

        int i, j, sum=0;

        for (i = 1; i <= n; i++)
            for (j = 1; j <= 10000; j++) {
                sum = sum + j;
            }

        endTime = System.nanoTime();

        System.out.println("\nLoop A ==> " + (endTime - startTime) + " ns <===");
        System.out.println("Sum = "+sum);
    }
    public static void loopC (int n) {
        // Loop C
        startTime = System.nanoTime();

        int i, j, k,  sum=0;

        for (i = 1; i <= n; i++)
            for (j = 1; j <= n; j++)
                for (k = 1; k <= n; k++)
                    sum = sum + k;


        endTime = System.nanoTime();

        System.out.println("\nLoop C ==> " + (endTime - startTime) + " ns <===");
        System.out.println("Sum = "+sum);
    }
}

