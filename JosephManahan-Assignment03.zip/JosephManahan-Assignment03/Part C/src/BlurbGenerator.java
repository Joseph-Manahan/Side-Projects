/*
 * **********************************************
 * San Francisco State University
 * CSC 220 -  Data Structures
 * File Name: BlurbGenerator.java
 * Author: Java Foundation
 * Author: Duc Ta
 * Author: <Joseph> <Manahan>
 * **********************************************
 */

import java.util.Random;

public class BlurbGenerator {
    Random random = new Random();

    /**
     * Instantiates a random number generator needed for blurb creation.
     */
    public BlurbGenerator() {
    }

    /**
     * Generates and returns a random Blurb. A Blurb is a Whoozit followed by
     * one or more Whatzits.
     */
    public String makeBlurb() {
        String blurb = makeWhoozit() + makeMultiWhatzits();
        return blurb;
    }

    /**
     * Generates a random Whoozit. A Whoozit is the character 'x' followed by
     * zero or more 'y's.
     */
    private String makeWhoozit() {
        String whoozit = "x";
        return whoozit + makeYString();
    }

    /**
     * Recursively generates a string of zero or more 'y's.
     */
    private String makeYString() {
        int amtOfY = random.nextInt();
        if (amtOfY>1) {
            return "y" +makeYString(); //recursive call
        } else
            return "";
    }

    /**
     * Recursively generates a string of one or more Whatzits.
     */
    private String makeMultiWhatzits() {
        int amtOfWhatzits = random.nextInt();
        if (amtOfWhatzits > 1) {
            return makeWhatzit() + makeMultiWhatzits(); //recursive call 
        } else
            return makeWhatzit();
    }

    /**
     * Generates a random Whatzit. A Whatzit is a 'q' followed by either a 'z'
     * or a 'd', followed by a Whoozit.
     */
    private String makeWhatzit() {
        String whatzit = "q";
        int zd = random.nextInt(2);
        if (zd == 1) {
            return whatzit + "z" + makeWhoozit();
        } else
            return whatzit + "d" + makeWhoozit();
    }
}