/*
 * **********************************************
 * San Francisco State University
 * CSC 220 -  Data Structures
 * File Name: Assignment02PartE02.java
 * Author: Duc Ta
 * Author: <Joseph> <Manahan>
 * **********************************************
 */

import java.util.Scanner;

public class Assignment3PartE2 {

    static long startTime;
    static long endTime;

    public static void main(String args[]) {
        Scanner in = new Scanner (System.in);
        int n;
        System.out.print("Enter value for n (type '002' to break):");
        n = in.nextInt();
        do {
            loopA(n); loopB(n);
            System.out.print("\nEnter value for n (type '002' to break):");
            n = in.nextInt();
        } while (n != 002);
            System.out.println("End");
    }

    public static void loopA (int n) {
        // Loop A
        startTime = System.nanoTime();

        int i, j, sum=0;

        for (i = 1; i <= n; i++)
            for (j = 1; j <= 10000; j++) {
                sum = sum + j;
            }

        endTime = System.nanoTime();

        System.out.println("\nLoop A ==> " + (endTime - startTime) + " ns <===");
        System.out.println("Sum = "+sum);
    }
    public static void loopB (int n) {
        // Loop B
        startTime = System.nanoTime();

        int i, j,  sum=0;

        for (i = 1; i <= n; i++)
            for (j = 1; j <= n; j++) {
                sum = sum + j;
            }

        endTime = System.nanoTime();

        System.out.println("\nLoop B ==> " + (endTime - startTime) + " ns <===");
        System.out.println("Sum = "+sum);
    }
}
