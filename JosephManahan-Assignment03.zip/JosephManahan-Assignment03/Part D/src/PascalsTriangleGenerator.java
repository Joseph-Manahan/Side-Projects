/*
 * **********************************************
 * San Francisco State University
 * CSC 220 -  Data Structures
 * File Name: PascalsTriangleGenerator.java
 * Author: Java Foundation
 * Author: Duc Ta
 * Author: <First Name> <Last Name>
 * **********************************************
 */

public class PascalsTriangleGenerator {

    public PascalsTriangleGenerator() {
    }

    public int[] computeRow(int rowToCompute) {
        if (rowToCompute == 1) {
            return new int [] {1};
        } else {
            int lastRow [] = computeRow(rowToCompute-1);
            int newRow [] = new int [lastRow.length+1];

            newRow[0]=1;
            newRow[newRow.length-1]=1;

            for (int i=0; i<lastRow.length-1; i++) {
                newRow[i+1] = lastRow[i] + lastRow[i+1];
            }

            return newRow;
        }
    }

}
