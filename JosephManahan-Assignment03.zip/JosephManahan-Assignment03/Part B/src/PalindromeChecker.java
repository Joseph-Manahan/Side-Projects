/*
 * **********************************************
 * San Francisco State University
 * CSC 220 -  Data Structures
 * File Name: PalindromeChecker.java
 * Author: Frank M. Carrano
 * Author: Timothy M. Henry
 * Author: Duc Ta
 * Author: <Joseph> <Manahan>
 * **********************************************
 */

import java.util.Scanner;

//
// - Do not change the "main" method.
// - Please ADD CODE to complete implementing the program
//
public class PalindromeChecker {

    private static boolean isPalindrome(String string) {
        // Initializing new stack for palindrome characters
        StackInterface<Character> palindromeStack = new OurStack<>();


        string = string.toLowerCase(); //ignores casing on letters
        string = string.replaceAll("[\\W]",""); //ignores special characters

        String compareString =""; //initialize a new string for comparison

        //for loop to push new characters into the stack
        for (int i=0; i<string.length();i++) {
            palindromeStack.push(string.charAt(i));
        }

        //pops out the new characters to compare to the new string
        while (!palindromeStack.isEmpty()) {
            compareString += palindromeStack.pop();
        }

        //true/false statement to see if the string is a palindrome
        return compareString.equals(string);
    }


    //
    // - Do not change the "main" method.
    // - Please ADD CODE to complete implementing the program
    //
    public static void main(String[] args) {
        //
        // - Do not change the "main" method.
        // - Please ADD CODE to complete implementing the program
        //
        Scanner input = new Scanner(System.in);
        System.out.print("[>>] Enter a string (or a ! to exit): ");
        String string = input.nextLine();

        while (!string.equals("!")) {
            if (isPalindrome(string)) {
                System.out.println(" [+] Yes. \"" + string + "\" IS a palindrome!");
            } else {
                System.out.println(" [-] No. \"" + string + "\" is NOT a palindrome!");
            }
            System.out.print("[>>] Enter a string: ");
            string = input.nextLine();
        }

        System.out.println("[<<] Thank you!");
        //
        // - Do not change the "main" method.
        // - Please ADD CODE to complete implementing the program
        //
    }
}